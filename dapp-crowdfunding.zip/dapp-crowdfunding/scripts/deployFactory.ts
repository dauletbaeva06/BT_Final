import hre from "hardhat";

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deployer:", deployer.address);

  const Factory = await hre.ethers.getContractFactory("CampaignFactory");
  const factory = await Factory.deploy();
  await factory.waitForDeployment();

  console.log("CampaignFactory deployed to:", await factory.getAddress());
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
