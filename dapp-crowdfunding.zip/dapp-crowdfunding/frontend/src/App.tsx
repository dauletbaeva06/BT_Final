import { useEffect, useMemo, useState } from "react";
import { BrowserProvider, Contract, formatEther, parseEther } from "ethers";
import { CAMPAIGN_ABI, ERC20_ABI, FACTORY_ABI } from "./abi";

const FACTORY_ADDRESS = import.meta.env.VITE_FACTORY_ADDRESS as string;

type CampaignItem = {
  address: string;
  owner: string;
  title: string;
  description: string;
  goalWei: bigint;
  deadline: bigint;
  totalRaisedWei: bigint;
  rewardToken: string;
};

function short(addr: string) {
  return addr ? addr.slice(0, 6) + "…" + addr.slice(-4) : "";
}

export default function App() {
  const [provider, setProvider] = useState<BrowserProvider | null>(null);
  const [account, setAccount] = useState<string>("");
  const [networkOk, setNetworkOk] = useState<boolean>(true);

  const [campaigns, setCampaigns] = useState<CampaignItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");

  // Create form
  const [newTitle, setNewTitle] = useState("My Campaign");
  const [newDesc, setNewDesc] = useState("Help me fund this project!");
  const [newGoalEth, setNewGoalEth] = useState("0.1");
  const [newDurationHours, setNewDurationHours] = useState("24");

  const factory = useMemo(() => {
    if (!provider || !FACTORY_ADDRESS) return null;
    return new Contract(FACTORY_ADDRESS, FACTORY_ABI, provider);
  }, [provider]);

  async function connect() {
    setError("");
    if (!(window as any).ethereum) {
      setError("MetaMask not found. Install MetaMask extension/app.");
      return;
    }
    const p = new BrowserProvider((window as any).ethereum);
    await p.send("eth_requestAccounts", []);
    const signer = await p.getSigner();
    const addr = await signer.getAddress();

    const net = await p.getNetwork();
    // Sepolia chainId = 11155111
    setNetworkOk(net.chainId === 11155111n);

    setProvider(p);
    setAccount(addr);
  }

  async function refreshCampaigns() {
    if (!factory) return;
    setLoading(true);
    setError("");
    try {
      const addrs: string[] = await factory.getCampaigns();
      const items: CampaignItem[] = [];
      for (const a of addrs) {
        const c = new Contract(a, CAMPAIGN_ABI, provider!);
        const [owner, title, description, goalWei, deadline, totalRaisedWei, rewardToken] =
          await Promise.all([
            c.owner(),
            c.title(),
            c.description(),
            c.goalWei(),
            c.deadline(),
            c.totalRaisedWei(),
            c.rewardToken(),
          ]);

        items.push({ address: a, owner, title, description, goalWei, deadline, totalRaisedWei, rewardToken });
      }
      // newest first
      items.reverse();
      setCampaigns(items);
    } catch (e: any) {
      setError(e?.message || "Failed to load campaigns");
    } finally {
      setLoading(false);
    }
  }

  async function createCampaign() {
    if (!provider || !factory) return;
    setLoading(true);
    setError("");
    try {
      const signer = await provider.getSigner();
      const factoryWithSigner = factory.connect(signer);

      const goalWei = parseEther(newGoalEth);
      const durationSeconds = BigInt(Math.max(1, parseInt(newDurationHours || "1", 10))) * 3600n;

      const tx = await factoryWithSigner.createCampaign(newTitle, newDesc, goalWei, durationSeconds);
      await tx.wait();
      await refreshCampaigns();
    } catch (e: any) {
      setError(e?.shortMessage || e?.message || "Create failed");
    } finally {
      setLoading(false);
    }
  }

  async function contribute(campaignAddress: string, ethAmount: string) {
    if (!provider) return;
    setLoading(true);
    setError("");
    try {
      const signer = await provider.getSigner();
      const c = new Contract(campaignAddress, CAMPAIGN_ABI, signer);
      const tx = await c.contribute({ value: parseEther(ethAmount) });
      await tx.wait();
      await refreshCampaigns();
    } catch (e: any) {
      setError(e?.shortMessage || e?.message || "Contribute failed");
    } finally {
      setLoading(false);
    }
  }

  async function getRewardBalance(tokenAddress: string) {
    if (!provider || !account) return "";
    const t = new Contract(tokenAddress, ERC20_ABI, provider);
    const [sym, dec, bal] = await Promise.all([t.symbol(), t.decimals(), t.balanceOf(account)]);
    // ethers formatUnits without importing: just do string math is annoying; we can use formatEther if dec==18
    const readable = dec === 18 ? formatEther(bal) : bal.toString();
    return `${readable} ${sym}`;
  }

  useEffect(() => {
    // auto-detect provider if available
    if ((window as any).ethereum) setProvider(new BrowserProvider((window as any).ethereum));
  }, []);

  useEffect(() => {
    if (provider && factory) refreshCampaigns();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [provider, factory]);

  return (
    <div style={{ maxWidth: 980, margin: "24px auto", padding: 16, fontFamily: "system-ui, -apple-system, Segoe UI, Roboto" }}>
      <h1 style={{ marginBottom: 4 }}>Crowdfunding DApp (Sepolia)</h1>
      <p style={{ marginTop: 0, opacity: 0.8 }}>
        Create campaigns, contribute with MetaMask, and earn internal reward tokens (CRT).
      </p>

      {!FACTORY_ADDRESS && (
        <div style={{ padding: 12, border: "1px solid #f0c", borderRadius: 12, marginBottom: 16 }}>
          <b>Missing VITE_FACTORY_ADDRESS</b>
          <div>Set it in frontend/.env after deploying the factory.</div>
        </div>
      )}

      <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 18 }}>
        <button onClick={connect} style={{ padding: "10px 14px", borderRadius: 12, border: "1px solid #ddd", cursor: "pointer" }}>
          {account ? `Connected: ${short(account)}` : "Connect MetaMask"}
        </button>
        {account && (
          <span style={{ padding: "6px 10px", borderRadius: 999, border: "1px solid #ddd" }}>
            Network: {networkOk ? "Sepolia ✅" : "Wrong network ❌ (switch to Sepolia)"}
          </span>
        )}
        {loading && <span>Working…</span>}
      </div>

      {error && (
        <div style={{ padding: 12, border: "1px solid #f55", borderRadius: 12, marginBottom: 16 }}>
          <b>Error:</b> {error}
        </div>
      )}

      <section style={{ padding: 16, border: "1px solid #eee", borderRadius: 16, marginBottom: 18 }}>
        <h2 style={{ marginTop: 0 }}>Create campaign</h2>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <label>
            Title
            <input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ddd" }} />
          </label>
          <label>
            Goal (ETH)
            <input value={newGoalEth} onChange={(e) => setNewGoalEth(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ddd" }} />
          </label>
          <label style={{ gridColumn: "1 / -1" }}>
            Description
            <input value={newDesc} onChange={(e) => setNewDesc(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ddd" }} />
          </label>
          <label>
            Duration (hours)
            <input value={newDurationHours} onChange={(e) => setNewDurationHours(e.target.value)} style={{ width: "100%", padding: 10, borderRadius: 10, border: "1px solid #ddd" }} />
          </label>
        </div>

        <div style={{ marginTop: 12 }}>
          <button
            onClick={createCampaign}
            disabled={!account || !networkOk || !FACTORY_ADDRESS}
            style={{ padding: "10px 14px", borderRadius: 12, border: "1px solid #ddd", cursor: "pointer" }}
          >
            Create
          </button>
        </div>
      </section>

      <section style={{ padding: 16, border: "1px solid #eee", borderRadius: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{ marginTop: 0 }}>Campaigns</h2>
          <button onClick={refreshCampaigns} style={{ padding: "8px 12px", borderRadius: 12, border: "1px solid #ddd", cursor: "pointer" }}>
            Refresh
          </button>
        </div>

        {campaigns.length === 0 ? (
          <p style={{ opacity: 0.8 }}>No campaigns yet.</p>
        ) : (
          <div style={{ display: "grid", gap: 12 }}>
            {campaigns.map((c) => (
              <CampaignCard
                key={c.address}
                c={c}
                canAct={!!account && networkOk}
                onContribute={contribute}
                getRewardBalance={getRewardBalance}
              />
            ))}
          </div>
        )}
      </section>

      <footer style={{ marginTop: 20, opacity: 0.7 }}>
        Tip: reward is 100 CRT per 1 ETH contributed.
      </footer>
    </div>
  );
}

function CampaignCard({
  c,
  canAct,
  onContribute,
  getRewardBalance,
}: {
  c: CampaignItem;
  canAct: boolean;
  onContribute: (addr: string, ethAmount: string) => Promise<void>;
  getRewardBalance: (token: string) => Promise<string>;
}) {
  const [amount, setAmount] = useState("0.01");
  const [rewardBal, setRewardBal] = useState<string>("");

  useEffect(() => {
    setRewardBal("");
  }, [c.rewardToken]);

  return (
    <div style={{ border: "1px solid #eee", borderRadius: 16, padding: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <h3 style={{ margin: 0 }}>{c.title}</h3>
          <div style={{ opacity: 0.8 }}>{c.description}</div>
          <div style={{ marginTop: 6, fontSize: 13, opacity: 0.8 }}>
            Campaign: {short(c.address)} · Owner: {short(c.owner)} · RewardToken: {short(c.rewardToken)}
          </div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div><b>Raised:</b> {formatEther(c.totalRaisedWei)} ETH</div>
          <div><b>Goal:</b> {formatEther(c.goalWei)} ETH</div>
          <div style={{ fontSize: 13, opacity: 0.8 }}>
            Deadline: {new Date(Number(c.deadline) * 1000).toLocaleString()}
          </div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, marginTop: 12, alignItems: "center", flexWrap: "wrap" }}>
        <input
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={{ padding: 10, borderRadius: 10, border: "1px solid #ddd", width: 140 }}
        />
        <button
          disabled={!canAct}
          onClick={() => onContribute(c.address, amount)}
          style={{ padding: "10px 14px", borderRadius: 12, border: "1px solid #ddd", cursor: "pointer" }}
        >
          Contribute (ETH)
        </button>

        <button
          onClick={async () => setRewardBal(await getRewardBalance(c.rewardToken))}
          style={{ padding: "10px 14px", borderRadius: 12, border: "1px solid #ddd", cursor: "pointer" }}
        >
          Check my CRT
        </button>

        {rewardBal && <span style={{ opacity: 0.9 }}><b>Balance:</b> {rewardBal}</span>}
      </div>
    </div>
  );
}
