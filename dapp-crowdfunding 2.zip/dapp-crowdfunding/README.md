# Crowdfunding DApp (Sepolia testnet)

This project is a decentralized crowdfunding app that runs **only on an Ethereum test network** (Sepolia) and uses **free test ETH**.

## Features
- Create crowdfunding campaigns (via `CampaignFactory`)
- Contribute to campaigns with test ETH (MetaMask)
- Receive internal reward token `CRT` for contributions
- Frontend securely interacts with blockchain via MetaMask

---

## 1) Architecture Overview
- **Smart contracts (Hardhat)**
  - `CampaignFactory`: creates campaigns and tracks their addresses
  - `Campaign`: holds campaign data, accepts contributions, allows owner withdrawal after deadline
  - `RewardToken (CRT)`: ERC-20 reward token minted on contributions
- **Frontend (Vite + React + ethers v6)**
  - Connect MetaMask
  - Create campaigns, list campaigns, contribute, check CRT balance

---

## 2) Setup (Smart contracts)

### Install
```bash
npm install
```

### Create `.env`
Copy `.env.example` to `.env` and fill:
- `SEPOLIA_RPC_URL`
- `PRIVATE_KEY` (TEST wallet only)

### Compile
```bash
npm run compile
```

### Deploy to Sepolia
```bash
npm run deploy:sepolia
```

It will print `CampaignFactory deployed to: 0x...`
Save this address for the frontend.

---

## 3) Setup (Frontend)

```bash
cd frontend
npm install
```

Create `frontend/.env` from `frontend/.env.example` and set:
- `VITE_FACTORY_ADDRESS=0x...` (your deployed factory address)

Run:
```bash
npm run dev
```

Open the local URL shown by Vite. Make sure MetaMask is on **Sepolia**.

---

## 4) How reward works
Reward formula is in `Campaign.contribute()`:

- 1 ETH => 100 CRT (18 decimals)
- `rewardAmount = msg.value * 100`

So if you contribute `0.01 ETH` you receive `1 CRT`.

---

## 5) How to get test ETH (Sepolia)
1. In MetaMask switch network to **Sepolia**
2. Copy your wallet address
3. Use a Sepolia faucet (free test ETH)
   - Common options: Alchemy faucet, QuickNode faucet, Google Cloud web3 faucet, etc.
4. After receiving funds, you can deploy and contribute.

---

## 6) Notes / Quality
- Uses `ReentrancyGuard` for contribution + withdrawal
- Uses events for UX (`CampaignCreated`, `Contributed`, `Withdrawn`)
- Works with MetaMask via `ethers` BrowserProvider + signer
