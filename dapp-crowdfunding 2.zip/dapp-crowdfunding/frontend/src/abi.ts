export const FACTORY_ABI = [
  "function createCampaign(string title,string description,uint256 goalWei,uint256 durationSeconds) returns (address campaignAddress,address rewardTokenAddress)",
  "function getCampaigns() view returns (address[])",
  "event CampaignCreated(address indexed campaign,address indexed owner,address rewardToken)"
] as const;

export const CAMPAIGN_ABI = [
  "function owner() view returns (address)",
  "function title() view returns (string)",
  "function description() view returns (string)",
  "function goalWei() view returns (uint256)",
  "function deadline() view returns (uint256)",
  "function totalRaisedWei() view returns (uint256)",
  "function rewardToken() view returns (address)",
  "function contribute() payable",
  "function contributionsWei(address) view returns (uint256)"
] as const;

export const ERC20_ABI = [
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function balanceOf(address) view returns (uint256)"
] as const;
